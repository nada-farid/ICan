<?php

return [
    'site_title' => 'Ican',
];
